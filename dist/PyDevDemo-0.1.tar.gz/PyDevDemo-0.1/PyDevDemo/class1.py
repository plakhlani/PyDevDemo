# In the Class1 File
import numpy as np
from scrapeasy import Webpage
import time